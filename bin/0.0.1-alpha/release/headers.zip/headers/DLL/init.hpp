#include "dll.hpp"

namespace PandoraEngine
{
    DLL void init();
}