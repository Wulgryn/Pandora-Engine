namespace utils
{
    namespace Bool
    {
        typedef unsigned char Bool;
        constexpr Bool TRUE = 1;
        constexpr Bool FALSE = 0;
    }
}